package tv.porst.jhexview;

import java.util.EventListener;

public interface IDataChangedListener extends EventListener
{
  void dataChanged(DataChangedEvent event);
}

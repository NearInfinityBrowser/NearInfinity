package tv.porst.splib.binaryparser;

/**
 * This package contains classes for parsing binary data. The main class
 * of this package is {@link BinaryParser}. Using this class you can parse
 * binary data into the types defined in the other classes.
 */

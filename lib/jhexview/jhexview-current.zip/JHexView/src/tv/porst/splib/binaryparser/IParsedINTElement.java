package tv.porst.splib.binaryparser;

/**
 * Interface to be implemented by parsed integer values.
 */
public interface IParsedINTElement extends IFileElement
{
}

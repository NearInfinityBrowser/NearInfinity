package tv.porst.splib.gui.caret;

/**
 * This package contains classes that simulate a caret in custom components.
 */

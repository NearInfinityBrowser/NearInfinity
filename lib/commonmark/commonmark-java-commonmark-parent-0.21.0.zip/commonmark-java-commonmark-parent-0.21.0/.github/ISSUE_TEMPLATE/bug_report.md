---
name: Bug report
about: Some input not render as you expect? Include an example so we can help
title: ''
labels: bug
assignees: ''

---

Steps to reproduce the problem (provide example Markdown if applicable):

```
my markdown
```

Expected behavior:

```
expected HTML
```

Actual behavior:

```
actual HTML
```

(Also see what the reference implementation does: https://spec.commonmark.org/dingus/)

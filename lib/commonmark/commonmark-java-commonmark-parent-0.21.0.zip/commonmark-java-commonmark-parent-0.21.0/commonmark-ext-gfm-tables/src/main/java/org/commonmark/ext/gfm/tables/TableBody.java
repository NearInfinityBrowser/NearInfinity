package org.commonmark.ext.gfm.tables;

import org.commonmark.node.CustomNode;

/**
 * Body part of a {@link TableBlock} containing {@link TableRow TableRows}.
 */
public class TableBody extends CustomNode {
}

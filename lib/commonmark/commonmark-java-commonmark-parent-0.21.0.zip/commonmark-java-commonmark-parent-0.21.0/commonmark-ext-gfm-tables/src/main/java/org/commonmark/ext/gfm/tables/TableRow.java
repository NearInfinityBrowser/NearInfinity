package org.commonmark.ext.gfm.tables;

import org.commonmark.node.CustomNode;

/**
 * Table row of a {@link TableHead} or {@link TableBody} containing {@link TableCell TableCells}.
 */
public class TableRow extends CustomNode {
}

package org.commonmark.ext.front.matter;

import org.commonmark.node.CustomBlock;

public class YamlFrontMatterBlock extends CustomBlock {
}

/**
 * Types for extending block parsing
 */
package org.commonmark.parser.block;

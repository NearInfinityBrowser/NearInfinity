package org.commonmark.parser.block;

public abstract class AbstractBlockParserFactory implements BlockParserFactory {
}

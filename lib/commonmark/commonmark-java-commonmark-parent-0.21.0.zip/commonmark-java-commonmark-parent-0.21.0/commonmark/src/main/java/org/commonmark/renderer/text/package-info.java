/**
 * Text content rendering (see {@link org.commonmark.renderer.text.TextContentRenderer})
 */
package org.commonmark.renderer.text;

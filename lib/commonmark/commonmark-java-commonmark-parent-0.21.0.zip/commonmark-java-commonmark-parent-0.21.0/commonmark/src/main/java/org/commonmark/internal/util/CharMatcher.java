package org.commonmark.internal.util;

public interface CharMatcher {

    boolean matches(char c);
}

package org.commonmark.internal.inline;

public class AsteriskDelimiterProcessor extends EmphasisDelimiterProcessor {

    public AsteriskDelimiterProcessor() {
        super('*');
    }
}

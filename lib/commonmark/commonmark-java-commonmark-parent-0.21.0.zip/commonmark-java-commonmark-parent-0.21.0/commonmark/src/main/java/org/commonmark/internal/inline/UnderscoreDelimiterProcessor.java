package org.commonmark.internal.inline;

public class UnderscoreDelimiterProcessor extends EmphasisDelimiterProcessor {

    public UnderscoreDelimiterProcessor() {
        super('_');
    }
}

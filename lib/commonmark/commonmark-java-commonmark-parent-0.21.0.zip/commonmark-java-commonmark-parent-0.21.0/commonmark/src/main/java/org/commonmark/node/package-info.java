/**
 * AST node types (see {@link org.commonmark.node.Node}) and visitors (see {@link org.commonmark.node.AbstractVisitor})
 */
package org.commonmark.node;

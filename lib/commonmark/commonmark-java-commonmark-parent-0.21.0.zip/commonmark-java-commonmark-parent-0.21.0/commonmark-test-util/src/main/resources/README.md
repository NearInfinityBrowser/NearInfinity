These files are copied from the CommonMark repositories, namely:

https://github.com/commonmark/commonmark-spec/blob/master/spec.txt
https://github.com/commonmark/cmark/blob/master/test/regression.txt
https://github.com/commonmark/commonmark.js/blob/master/test/regression.txt

They are licensed as stated in those repositories.

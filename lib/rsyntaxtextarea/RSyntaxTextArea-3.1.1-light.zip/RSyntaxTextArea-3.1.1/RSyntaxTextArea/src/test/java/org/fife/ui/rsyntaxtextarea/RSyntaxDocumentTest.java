/*
 * 01/12/2015
 *
 * This library is distributed under a modified BSD license.  See the included
 * LICENSE file for details.
 */
package org.fife.ui.rsyntaxtextarea;

import java.util.ArrayList;
import java.util.List;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import org.junit.Assert;
import org.junit.Test;


/**
 * Unit tests for {@link RSyntaxDocument}.
 *
 * @author Robert Futrell
 * @version 1.0
 */
public class RSyntaxDocumentTest {

	private RSyntaxDocument doc;


	/**
	 * Inserts code for "Hello world" in C into a document.
	 *
	 * @param doc The document.
	 * @throws Exception If something goes wrong (which should not happen).
	 */
	private static final void insertHelloWorldC(RSyntaxDocument doc)
			throws Exception {
		String str = "#include <stdio.h>\n"
				+ "/*\n"
				+ " * Multi-line comment */\n"
				+ "int main(int argc, char **argv)\n"
				+ "{\n"
				+ "    printf(\"Hello world!\n\");\n"
				+ "\n"
				+ "}\n";
		doc.insertString(0, str, null);
	}


	@Test
	public void test1ArgConstructor() {
		String syntaxStyle = SyntaxConstants.SYNTAX_STYLE_JAVA;
		doc = new RSyntaxDocument(syntaxStyle);
		//Assert.assertEquals(syntaxStyle, doc.getSyntaxStyle());
	}
	
	
	@Test
	public void test2ArgConstructor() {
		
		String syntaxStyle = SyntaxConstants.SYNTAX_STYLE_JAVA;
		
		// Standard case, taking default TokenMakerFactory
		doc = new RSyntaxDocument(null, syntaxStyle);
		//Assert.assertEquals(syntaxStyle, doc.getSyntaxStyle());
		
		// Taking a custom TokenMakerFactory
		TokenMakerFactory customTmf = new AbstractTokenMakerFactory() {
			@Override
			protected void initTokenMakerMap() {
				// Do nothing
			}
		};
		doc = new RSyntaxDocument(customTmf, syntaxStyle);
		//Assert.assertEquals(syntaxStyle, doc.getSyntaxStyle());
		
	}
	
	
	@Test
	public void testFireDocumentEvent_InsertWithNoNewLines() throws Exception {
		
		String syntaxStyle = SyntaxConstants.SYNTAX_STYLE_JAVA;
		doc = new RSyntaxDocument(syntaxStyle);
		
		TestDocumentListener l = new TestDocumentListener();
		doc.addDocumentListener(l);
		
		// Two events sent - one "change" event containing line range AFTER
		// insert to repaint, second one is actual "insert" event.
		int offs = 0;
		String text = "package org.fife;";
		doc.insertString(offs, text, null);
		Assert.assertEquals(2, l.events.size());
		DocumentEvent e = l.events.get(0);
		// offset and length == start and end lines AFTER insert with new EOL tokens
		assertDocumentEvent(e, DocumentEvent.EventType.CHANGE, 0, 0);
		e = l.events.get(1);
		assertDocumentEvent(e, DocumentEvent.EventType.INSERT, 0, text.length());
		
	}
	
	
	@Test
	public void testFireDocumentEvent_InsertWithTwoNewLines() throws Exception {

		String syntaxStyle = SyntaxConstants.SYNTAX_STYLE_C;
		doc = new RSyntaxDocument(syntaxStyle);
		insertHelloWorldC(doc);

		TestDocumentListener l = new TestDocumentListener();
		doc.addDocumentListener(l);
		
		// Two events sent - one "change" event containing line range AFTER
		// insert repaint, second one is actual "insert" event.
		int oldLen = doc.getLength();
		String text = "// Inserted line 1\nprintf(\"This is working\n\");";
		doc.insertString(oldLen - 4, text, null);
		Assert.assertEquals(2, l.events.size());
		DocumentEvent e = l.events.get(0);
		// offset and length == start and end lines AFTER insert with new EOL tokens
		// In this case a new line was "added" by this change.
		assertDocumentEvent(e, DocumentEvent.EventType.CHANGE, 8, 8);
		e = l.events.get(1);
		assertDocumentEvent(e, DocumentEvent.EventType.INSERT,
				oldLen - 4, text.length());
		
	}
	
	
	@Test
	public void testFireDocumentEvent_InsertWithTwoNewLinesOneReplaced() throws Exception {

		String syntaxStyle = SyntaxConstants.SYNTAX_STYLE_C;
		doc = new RSyntaxDocument(syntaxStyle);
		insertHelloWorldC(doc);

		TestDocumentListener l = new TestDocumentListener();
		doc.addDocumentListener(l);
		
		int oldLen = doc.getLength();
		String text = "// Inserted line 1\nprintf(\"This is working\n\");";
		doc.replace(oldLen - 4, 1, text, null);

		// Four events sent - One change/remove pair and one change/insert
		// pair.  Remove is the one line replaced.
		Assert.assertEquals(4, l.events.size());

		DocumentEvent e = l.events.get(0);
		// offset and length == start and end lines AFTER remove with new EOL
		// tokens. In this case a new line was "added" by this change.
		assertDocumentEvent(e, DocumentEvent.EventType.CHANGE, 6, 6);
		e = l.events.get(1);
		assertDocumentEvent(e, DocumentEvent.EventType.REMOVE,
				oldLen - 4, 1);

		e = l.events.get(2);
		// offset and length == start and end lines AFTER insert with new EOL
		// tokens.  In this case a new line was "added" by this change.
		assertDocumentEvent(e, DocumentEvent.EventType.CHANGE, 8, 8);
		e = l.events.get(3);
		assertDocumentEvent(e, DocumentEvent.EventType.INSERT,
				oldLen - 4, text.length());
	}
	
	
	@Test
	public void testFireDocumentEvent_RemoveWithinOneLine() throws Exception {

		String syntaxStyle = SyntaxConstants.SYNTAX_STYLE_C;
		doc = new RSyntaxDocument(syntaxStyle);
		insertHelloWorldC(doc);

		TestDocumentListener l = new TestDocumentListener();
		doc.addDocumentListener(l);
		
		doc.replace(52, 3, null, null); // Replace "main" with "m"

		// Two events sent - A change/remove pair.
		Assert.assertEquals(2, l.events.size());

		DocumentEvent e = l.events.get(0);
		// offset and length == start and end lines AFTER remove with new EOL
		// tokens. In this case a new line was "added" by this change.
		assertDocumentEvent(e, DocumentEvent.EventType.CHANGE, 3, 3);
		e = l.events.get(1);
		assertDocumentEvent(e, DocumentEvent.EventType.REMOVE, 52, 3);

	}


	@Test
	public void testGetClosestStandardTokenTypeForInternalType() throws Exception {

	}


	@Test
	public void testGetCompleteMarkupCloseTags() {

	}


	@Test
	public void testGetCurlyBracesDenoteCodeBlocks() {

	}


	@Test
	public void testGetLanguageIsMarkup() {

	}


	@Test
	public void testGetLastTokenTypeOnLine() throws Exception {

	}


	@Test(expected = IndexOutOfBoundsException.class)
	public void testGetLastTokenTypeOnLine_InvalidIndex() throws Exception {

		String syntaxStyle = SyntaxConstants.SYNTAX_STYLE_C;
		doc = new RSyntaxDocument(syntaxStyle);
		insertHelloWorldC(doc);

		Assert.assertEquals(TokenTypes.NULL, doc.getLastTokenTypeOnLine(1000));

	}


	@Test
	public void testGetLineCommentStartAndEnd() {

	}


	@Test
	public void testGetMarkOccurrencesOfTokenType() {

	}


	@Test
	public void testGetOccurrenceMarker() {
		// Not really much we can test here
		String syntaxStyle = SyntaxConstants.SYNTAX_STYLE_C;
		doc = new RSyntaxDocument(syntaxStyle);
		Assert.assertNotNull(doc.getOccurrenceMarker());
	}


	@Test
	public void testGetShouldIndentNextLine() throws Exception {

	}


	@Test
	public void testGetSyntaxStyle() {

		String syntaxStyle = SyntaxConstants.SYNTAX_STYLE_C;
		doc = new RSyntaxDocument(syntaxStyle);
		Assert.assertEquals(syntaxStyle, doc.getSyntaxStyle());

		syntaxStyle = SyntaxConstants.SYNTAX_STYLE_XML;
		doc.setSyntaxStyle(syntaxStyle);
		Assert.assertEquals(syntaxStyle, doc.getSyntaxStyle());

		syntaxStyle = "text/custom";
		doc.setSyntaxStyle(syntaxStyle);
		Assert.assertEquals(syntaxStyle, doc.getSyntaxStyle());

	}


	@Test
	public void testGetTokenListForLine() throws Exception {

	}


	@Test
	public void testInsertBreakSpecialHandling() {

	}


	@Test
	public void testIsIdentifierChar() {
		
		String syntaxStyle = SyntaxConstants.SYNTAX_STYLE_C;
		doc = new RSyntaxDocument(syntaxStyle);
		Assert.assertTrue(doc.isIdentifierChar(0, 'a'));
		Assert.assertFalse(doc.isIdentifierChar(0, '%'));

	}


	@Test
	public void testIterator() {
		// Not much to test here
		String syntaxStyle = SyntaxConstants.SYNTAX_STYLE_C;
		doc = new RSyntaxDocument(syntaxStyle);
		Assert.assertNotNull(doc.iterator());
	}


	@Test
	public void testSetSyntaxStyle() {

		String syntaxStyle = SyntaxConstants.SYNTAX_STYLE_C;
		doc = new RSyntaxDocument(syntaxStyle);
		Assert.assertEquals(syntaxStyle, doc.getSyntaxStyle());

		syntaxStyle = SyntaxConstants.SYNTAX_STYLE_XML;
		doc.setSyntaxStyle(syntaxStyle);
		Assert.assertEquals(syntaxStyle, doc.getSyntaxStyle());

		syntaxStyle = "text/custom";
		doc.setSyntaxStyle(syntaxStyle);
		Assert.assertEquals(syntaxStyle, doc.getSyntaxStyle());

	}


	@Test
	public void testSetSyntaxStyle_CustomTokenMaker() {

	}


	@Test
	public void testSetTokenMakerFactory() {

	}


	/**
	 * Verifies that the type, offset, and length of a
	 * <code>DocumentEvent</code> have expected values.
	 *
	 * @param e The event to check.
	 * @param eventType The expected event type.
	 * @param offs The expected offset.
	 * @param len The expected length.
	 * @throws AssertionError If any value is not as expected.
	 */
	private static final void assertDocumentEvent(DocumentEvent e,
			DocumentEvent.EventType eventType, int offs, int len) {
		Assert.assertEquals(eventType, e.getType());
		Assert.assertEquals(offs, e.getOffset());
		Assert.assertEquals(len, e.getLength());
	}


	/**
	 * A token maker factory with no mappings to languages.
	 */
	private static class EmptyTokenMakerFactory
			extends AbstractTokenMakerFactory {

		@Override
		protected void initTokenMakerMap() {
			// Do nothing
		}

	}


	/**
	 * Aggregates document events for examination.
	 */
	private static class TestDocumentListener implements DocumentListener {
		
		private List<DocumentEvent> events;
		
		public TestDocumentListener() {
			events = new ArrayList<DocumentEvent>();
		}
		
		@Override
		public void insertUpdate(DocumentEvent e) {
			events.add(e);
		}

		@Override
		public void removeUpdate(DocumentEvent e) {
			events.add(e);
		}

		@Override
		public void changedUpdate(DocumentEvent e) {
			events.add(e);
		}
		
	}
	
	
}

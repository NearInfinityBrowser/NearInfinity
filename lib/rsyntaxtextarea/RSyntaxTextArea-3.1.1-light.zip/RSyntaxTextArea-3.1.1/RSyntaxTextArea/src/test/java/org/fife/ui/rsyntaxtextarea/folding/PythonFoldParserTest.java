/*
 * This library is distributed under a modified BSD license.  See the included
 * LICENSE file for details.
 */
package org.fife.ui.rsyntaxtextarea.folding;


import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
import org.fife.ui.rsyntaxtextarea.SyntaxConstants;
import org.junit.Assert;
import org.junit.Test;

import java.util.List;

/**
 * Unit tests for the {@code PythonFoldParser} class.
 *
 * @author Robert Futrell
 * @version 1.0
 */
public class PythonFoldParserTest {

	@Test
	public void testGetFold_happyPath() {

	}
}

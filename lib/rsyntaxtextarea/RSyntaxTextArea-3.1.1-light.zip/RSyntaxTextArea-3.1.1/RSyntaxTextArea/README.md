# RSyntaxTextArea
This is the module containing the actual source code.
